import { AppShell } from "@/components/layout/app-shell";

export default function VerifyLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return <AppShell>{children}</AppShell>;
}
