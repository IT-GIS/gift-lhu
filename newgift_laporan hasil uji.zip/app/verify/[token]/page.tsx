import { ShieldCheck, ShieldX, ShieldOff } from "lucide-react";
import { getLhuDocumentByToken } from "@/lib/db/queries/lhu";
import { Card } from "@/components/ui/card";
import { QRCodeSVG } from "qrcode.react";
import { formatDate, getConcreteTypeLabel } from "@/lib/utils";

export default async function VerifyTokenPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const appUrl = process.env.APP_URL || "http://localhost:3000";
  const verifyUrl = `${appUrl}/verify/${token}`;

  const doc = await getLhuDocumentByToken(token);

  // Token not found
  if (!doc) {
    return <VerifyError title="Token Tidak Valid" message="Token verifikasi ini tidak ditemukan atau tidak aktif dalam sistem kami." icon="invalid" />;
  }

  // Token found but document is revoked
  if (doc.status === "revoked") {
    return (
      <VerifyError
        title="Dokumen Tidak Berlaku"
        message={`Laporan ini telah direvoke dan tidak lagi berlaku secara resmi.${doc.revokedReason ? ` Alasan: ${doc.revokedReason}` : ""}`}
        icon="revoked"
      />
    );
  }

  // Token's associated document is not published (shouldn't normally happen)
  if (doc.status !== "published") {
    return <VerifyError title="Dokumen Belum Terbit" message="Dokumen terkait token ini belum dipublikasikan." icon="invalid" />;
  }

  // Check that the active token actually matches (extra security check)
  if (!doc.activeToken || doc.activeToken.publicToken !== token || !doc.activeToken.isActive) {
    return <VerifyError title="Token Tidak Aktif" message="Token verifikasi ini sudah tidak aktif. Mungkin telah diterbitkan token baru." icon="invalid" />;
  }

  const customerName = doc.customer?.companyName ?? "—";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 py-12 px-4">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Valid Banner */}
        <div className="flex items-center gap-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-2xl p-5">
          <div className="h-12 w-12 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center shrink-0">
            <ShieldCheck className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <div className="font-bold text-emerald-800 dark:text-emerald-300 text-lg">
              Dokumen Terverifikasi
            </div>
            <div className="text-sm text-emerald-700 dark:text-emerald-400 mt-0.5">
              Laporan ini telah diverifikasi sebagai dokumen resmi laboratorium.
            </div>
          </div>
        </div>

        <Card className="bg-white dark:bg-slate-900 shadow-sm">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1 space-y-4">
              <div>
                <div className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">Nomor LHU</div>
                <div className="mt-1 text-2xl font-bold text-slate-900 dark:text-slate-100">{doc.lhuNumber}</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-muted-foreground">Pelanggan</div>
                  <div className="mt-1 font-medium">{customerName}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Nama Proyek</div>
                  <div className="mt-1 font-medium">{doc.projectName}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Jenis Pengujian</div>
                  <div className="mt-1 font-medium">{doc.testType}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Acuan</div>
                  <div className="mt-1 font-medium">{getConcreteTypeLabel(doc.concreteType)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Tanggal Terima</div>
                  <div className="mt-1 font-medium">{formatDate(doc.receivedDate.toISOString())}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Tanggal Uji</div>
                  <div className="mt-1 font-medium">{formatDate(doc.testingDate.toISOString())}</div>
                </div>
                {doc.publishedAt && (
                  <div className="col-span-2">
                    <div className="text-xs text-muted-foreground">Tanggal Publish</div>
                    <div className="mt-1 font-medium">{formatDate(doc.publishedAt.toISOString())}</div>
                  </div>
                )}
              </div>
            </div>

            {/* QR Code */}
            <div className="flex flex-col items-center gap-3 shrink-0">
              <div className="bg-white dark:bg-white p-4 rounded-2xl shadow-sm">
                <QRCodeSVG value={verifyUrl} size={140} />
              </div>
              <div className="text-xs text-center text-muted-foreground max-w-[160px]">
                Scan QR untuk verifikasi ulang dari perangkat lain
              </div>
            </div>
          </div>
        </Card>

        {/* Result Rows */}
        {doc.resultRows.length > 0 && (
          <Card className="bg-white dark:bg-slate-900 shadow-sm overflow-hidden p-0">
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 font-semibold">
              Hasil Pengujian ({doc.resultRows.length} sampel)
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/60">
                  <tr>
                    {["No", "Kode Sampel", "Umur", "Dimensi", "Beban Maks (kN)", "Kuat Tekan (MPa)", "Pola Hancur"].map((h) => (
                      <th key={h} className="px-4 py-3 text-left font-semibold text-slate-600 dark:text-slate-300 whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {doc.resultRows.map((row) => (
                    <tr key={row.id}>
                      <td className="px-4 py-3 font-medium">{row.rowNumber}</td>
                      <td className="px-4 py-3">{row.sampleCode}</td>
                      <td className="px-4 py-3">{row.ageDays} hari</td>
                      <td className="px-4 py-3">{row.dimension ?? "—"}</td>
                      <td className="px-4 py-3">{row.maxLoad ?? "—"}</td>
                      <td className="px-4 py-3 font-semibold text-indigo-600 dark:text-indigo-400">
                        {row.compressiveStrength ? `${row.compressiveStrength} MPa` : "—"}
                      </td>
                      <td className="px-4 py-3">{row.failurePattern ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        <div className="text-center text-xs text-muted-foreground pt-4">
          Verifikasi dilakukan pada {new Date().toLocaleString("id-ID")} ·{" "}
          <span className="font-mono">{token}</span>
        </div>
      </div>
    </div>
  );
}

function VerifyError({
  title,
  message,
  icon,
}: {
  title: string;
  message: string;
  icon: "invalid" | "revoked";
}) {
  const Icon = icon === "revoked" ? ShieldOff : ShieldX;
  const colorClass = icon === "revoked" ? "text-amber-600" : "text-red-600";
  const bgClass = icon === "revoked" ? "bg-amber-100" : "bg-red-100";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center p-4">
      <Card className="max-w-md w-full bg-white dark:bg-slate-900 shadow-xl text-center p-10">
        <div className={`h-16 w-16 rounded-full ${bgClass} flex items-center justify-center mx-auto`}>
          <Icon className={`h-8 w-8 ${colorClass}`} />
        </div>
        <h1 className="mt-6 text-2xl font-bold text-slate-900 dark:text-slate-100">{title}</h1>
        <p className="mt-3 text-muted-foreground leading-relaxed">{message}</p>
        <div className="mt-8 text-xs text-muted-foreground">
          Jika Anda merasa ini keliru, hubungi laboratorium yang menerbitkan dokumen ini.
        </div>
      </Card>
    </div>
  );
}
