import { redirect } from "next/navigation";

/**
 * Legacy route: /verify/[token]/[lhuId]
 * Sekarang verifikasi cukup dengan token saja.
 * Redirect ke halaman verifikasi baru yang sudah menggunakan DB.
 */
export default async function VerifyDetailPage({
  params,
}: {
  params: Promise<{ token: string; lhuId: string }>;
}) {
  const { token } = await params;
  redirect(`/verify/${token}`);
}
