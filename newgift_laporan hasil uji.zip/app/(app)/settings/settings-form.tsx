"use client";

import { useState, useTransition } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, CheckCircle } from "lucide-react";
import { saveSettingsAction } from "./actions";

interface Props {
  defaultValues: Record<string, string>;
}

export function SettingsForm({ defaultValues }: Props) {
  const [isSaving, startSave] = useTransition();
  const [successMsg, setSuccessMsg] = useState("");

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data: Record<string, string> = {};
    fd.forEach((value, key) => {
      if (typeof value === "string") data[key] = value;
    });

    startSave(async () => {
      const result = await saveSettingsAction(data);
      if (result.success) {
        setSuccessMsg("Pengaturan berhasil disimpan!");
        setTimeout(() => setSuccessMsg(""), 3000);
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {successMsg && (
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm font-medium">
          <CheckCircle className="h-4 w-4" />
          {successMsg}
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-2">
        <Card className="space-y-5 bg-white/85 dark:bg-slate-900/60 p-6 md:p-8">
          <div className="text-lg font-semibold text-slate-800 dark:text-slate-100">Branding & Identitas Lab</div>

          <div className="space-y-2">
            <Label htmlFor="company_name" className="dark:text-slate-300">Nama Perusahaan / Laboratorium</Label>
            <Input
              id="company_name"
              name="company_name"
              defaultValue={defaultValues.company_name ?? ""}
              placeholder="PT. Global Inspeksi Forensik Teknik"
              className="dark:bg-slate-800/50"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="company_address" className="dark:text-slate-300">Alamat</Label>
            <Textarea
              id="company_address"
              name="company_address"
              defaultValue={defaultValues.company_address ?? ""}
              rows={2}
              className="dark:bg-slate-800/50"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="company_email" className="dark:text-slate-300">Email</Label>
              <Input
                id="company_email"
                name="company_email"
                type="email"
                defaultValue={defaultValues.company_email ?? ""}
                className="dark:bg-slate-800/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company_phone" className="dark:text-slate-300">Telepon</Label>
              <Input
                id="company_phone"
                name="company_phone"
                defaultValue={defaultValues.company_phone ?? ""}
                className="dark:bg-slate-800/50"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="lhu_number_format" className="dark:text-slate-300">Format Nomor LHU</Label>
            <Input
              id="lhu_number_format"
              name="lhu_number_format"
              defaultValue={defaultValues.lhu_number_format ?? "LHU-BTN/{year}/{sequence}"}
              className="dark:bg-slate-800/50"
            />
            <p className="text-xs text-muted-foreground">Gunakan <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">{"{year}"}</code> dan <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">{"{sequence}"}</code> sebagai placeholder.</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="verification_base_url" className="dark:text-slate-300">Base URL Verifikasi Publik</Label>
            <Input
              id="verification_base_url"
              name="verification_base_url"
              defaultValue={defaultValues.verification_base_url ?? ""}
              placeholder="https://verify.gift-lab.id"
              className="dark:bg-slate-800/50"
            />
          </div>
        </Card>

        <Card className="space-y-5 bg-white/85 dark:bg-slate-900/60 p-6 md:p-8 flex flex-col">
          <div className="flex-1 space-y-5">
            <div className="text-lg font-semibold text-slate-800 dark:text-slate-100">Aturan Dokumen</div>

            <div className="space-y-2">
              <Label htmlFor="document_footer" className="dark:text-slate-300">Footer Dokumen Legal</Label>
              <Textarea
                id="document_footer"
                name="document_footer"
                rows={4}
                defaultValue={defaultValues.document_footer ?? ""}
                placeholder="Dokumen ini sah apabila diverifikasi pada halaman publik resmi laboratorium."
                className="dark:bg-slate-800/50"
              />
            </div>

            <div className="space-y-2">
              <Label className="dark:text-slate-300">Logo URL Saat Ini</Label>
              <div className="flex items-center gap-3">
                {defaultValues.logo_url && (
                  <img
                    src={defaultValues.logo_url}
                    alt="Logo"
                    className="h-12 w-12 object-contain rounded-lg border border-slate-200 bg-white p-1"
                  />
                )}
                <div className="text-sm text-muted-foreground">
                  {defaultValues.logo_url || "Belum ada logo."}
                </div>
              </div>
              <Input
                name="logo_url"
                defaultValue={defaultValues.logo_url ?? ""}
                placeholder="/gift-logo.png atau URL lengkap"
                className="dark:bg-slate-800/50"
              />
              <p className="text-xs text-muted-foreground">Masukkan path relatif (e.g. /gift-logo.png) atau URL absolut.</p>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-end">
            <Button
              type="submit"
              disabled={isSaving}
              className="w-full sm:w-auto px-8 bg-indigo-600 hover:bg-indigo-700 shadow-md"
            >
              {isSaving ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Menyimpan...</>
              ) : (
                "Simpan Pengaturan"
              )}
            </Button>
          </div>
        </Card>
      </div>
    </form>
  );
}
