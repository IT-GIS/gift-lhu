import Link from "next/link";
import { Filter, Plus, Search } from "lucide-react";
import { listLhuDocuments } from "@/lib/db/queries/lhu";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatDate, getConcreteTypeLabel } from "@/lib/utils";
import type { LhuStatus } from "@/lib/db/queries/lhu";

const validStatuses: LhuStatus[] = [
  "draft", "input_hasil", "review", "revisi", "approved", "published", "revoked",
];

export default async function LhuIndexPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; search?: string }>;
}) {
  const sp = await searchParams;
  const statusFilter = validStatuses.includes(sp.status as LhuStatus)
    ? (sp.status as LhuStatus)
    : undefined;

  const rows = await listLhuDocuments({
    status: statusFilter,
    search: sp.search,
    limit: 100,
  });

  return (
    <div className="space-y-6 md:space-y-8 pb-10">
      <PageHeader
        title="Data LHU"
        description="Daftar laporan hasil uji dengan fitur pencarian, filter, dan monitoring workflow."
        actions={
          <Button asChild className="bg-indigo-600 hover:bg-indigo-700 shadow-sm w-full sm:w-auto">
            <Link href="/lhu/new">
              <Plus className="mr-2 h-4 w-4" />
              Buat Draft LHU
            </Link>
          </Button>
        }
      />

      <Card className="bg-white/85 dark:bg-slate-900/80 p-4 md:p-6 shadow-sm border-slate-200 dark:border-slate-800">
        <form className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-muted-foreground" />
            <input
              name="search"
              defaultValue={sp.search}
              placeholder="Cari nomor LHU, pelanggan, proyek..."
              className="flex h-10 w-full rounded-md border border-input bg-background pl-10 pr-4 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:w-[480px] shrink-0">
            <select
              name="status"
              defaultValue={sp.status ?? ""}
              className="flex h-10 w-full rounded-md border border-input bg-white dark:bg-slate-900 dark:text-slate-300 dark:border-slate-700 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <option value="">Semua Status</option>
              <option value="draft">Draft</option>
              <option value="input_hasil">Input Hasil</option>
              <option value="review">Review QA</option>
              <option value="revisi">Revisi</option>
              <option value="approved">Approved</option>
              <option value="published">Published</option>
              <option value="revoked">Revoked</option>
            </select>
            <Button type="submit" variant="secondary" className="w-full">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>
        </form>
      </Card>

      <Card className="overflow-hidden bg-white/85 dark:bg-slate-900/80 p-0 shadow-sm border-slate-200 dark:border-slate-800">
        <div className="overflow-x-auto w-full">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50/80 dark:bg-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800 border-b border-slate-200 dark:border-slate-700 whitespace-nowrap">
                <TableHead className="font-semibold text-slate-700 dark:text-slate-300 h-12 px-5">Nomor LHU / Draft</TableHead>
                <TableHead className="font-semibold text-slate-700 dark:text-slate-300 h-12 px-5">Pelanggan</TableHead>
                <TableHead className="font-semibold text-slate-700 dark:text-slate-300 h-12 px-5">Nama Proyek</TableHead>
                <TableHead className="font-semibold text-slate-700 dark:text-slate-300 h-12 px-5 text-center">Status</TableHead>
                <TableHead className="font-semibold text-slate-700 dark:text-slate-300 h-12 px-5">Tgl Testing</TableHead>
                <TableHead className="font-semibold text-slate-700 dark:text-slate-300 h-12 px-5 text-center">Tindakan</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-slate-100 whitespace-nowrap">
              {rows.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                    Tidak ada data LHU ditemukan.
                  </TableCell>
                </TableRow>
              ) : (
                rows.map(({ doc, customer }) => (
                  <TableRow key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors">
                    <TableCell className="px-5 py-3.5">
                      <div className="font-semibold text-slate-800 dark:text-slate-100">{doc.lhuNumber || doc.documentCode}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{doc.testType} - {getConcreteTypeLabel(doc.concreteType)}</div>
                    </TableCell>
                    <TableCell className="px-5 py-3.5 font-medium text-slate-700 dark:text-slate-300">
                      {customer?.companyName ?? "—"}
                    </TableCell>
                    <TableCell className="px-5 py-3.5">
                      <div className="truncate max-w-[200px]" title={doc.projectName}>{doc.projectName}</div>
                    </TableCell>
                    <TableCell className="px-5 py-3.5 text-center">
                      <StatusBadge status={doc.status} />
                    </TableCell>
                    <TableCell className="px-5 py-3.5">
                      <div className="text-sm font-medium text-slate-700 dark:text-slate-300">{formatDate(doc.testingDate.toISOString())}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {doc.publishedAt ? formatDate(doc.publishedAt.toISOString()) : "Belum terbit"}
                      </div>
                    </TableCell>
                    <TableCell className="px-5 py-3.5">
                      <div className="flex justify-center gap-2">
                        <Button size="sm" variant="outline" className="h-8 text-xs font-semibold" asChild>
                          <Link href={`/lhu/${doc.id}`}>Detail</Link>
                        </Button>
                        {(doc.status === "draft" || doc.status === "revisi") && (
                          <Button size="sm" variant="outline" className="h-8 text-xs font-semibold hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200" asChild>
                            <Link href={`/lhu/${doc.id}/edit`}>Edit</Link>
                          </Button>
                        )}
                        {doc.status === "review" && (
                          <Button size="sm" variant="secondary" className="h-8 text-xs font-semibold" asChild>
                            <Link href={`/lhu/${doc.id}/review`}>Review QA</Link>
                          </Button>
                        )}
                        {doc.status === "approved" && (
                          <Button size="sm" className="h-8 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700" asChild>
                            <Link href={`/lhu/${doc.id}/publish`}>Publish</Link>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
