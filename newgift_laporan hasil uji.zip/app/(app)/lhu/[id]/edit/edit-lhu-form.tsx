"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Save, Loader2, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { GeneralInfoForm } from "@/components/lhu/general-info-form";
import { AttachmentForm } from "@/components/lhu/attachment-form";
import { TestResultsForm, TestRow } from "@/components/lhu/test-results-form";
import { updateLhuAction } from "./actions";

function createEmptyRow(): TestRow {
  return {
    id: Math.random().toString(36).substr(2, 9),
    kodeSampel: "",
    tanggalBuat: "",
    tanggalTest: "",
    berat: "",
    umur: "",
    ukuran: "",
    tekananMaksimum: "",
    teganganHancurMpa: "",
    teganganHancurOther: "",
    polaHancur: "",
    keterangan: "",
  };
}

export function EditLhuForm({ doc }: { doc: any }) {
  const router = useRouter();
  
  const initialRows: TestRow[] = (doc.resultRows && doc.resultRows.length > 0)
    ? doc.resultRows.map((r: any) => ({
        id: r.id || Math.random().toString(36).substr(2, 9),
        kodeSampel: r.sampleCode ?? "",
        tanggalBuat: r.castingDate ? new Date(r.castingDate).toISOString().split("T")[0] : "",
        tanggalTest: r.testingDate ? new Date(r.testingDate).toISOString().split("T")[0] : "",
        berat: String(r.weight ?? ""),
        umur: String(r.ageDays ?? ""),
        ukuran: String(r.dimension ?? ""),
        tekananMaksimum: String(r.maxLoad ?? ""),
        teganganHancurMpa: String(r.compressiveStrength ?? ""),
        teganganHancurOther: "",
        polaHancur: String(r.failurePattern ?? ""),
        keterangan: String(r.remarks ?? ""),
      }))
    : [createEmptyRow()];

  const [rows, setRows] = useState<TestRow[]>(initialRows);
  const [isPending, startTransition] = useTransition();

  const addRow = () => setRows([...rows, createEmptyRow()]);
  const removeRow = (id: string) => {
    if (rows.length > 1) setRows(rows.filter((r) => r.id !== id));
  };
  const updateRow = (id: string, field: keyof TestRow, value: string) => {
    setRows(rows.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
  };

  const handleSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);

    const input = {
      customer: String(fd.get("customer") || ""),
      projectName: String(fd.get("projectName") || ""),
      projectAddress: String(fd.get("projectAddress") || ""),
      referenceNumber: String(fd.get("referenceNumber") || ""),
      concreteType: String(fd.get("concreteType") || ""),
      testType: String(fd.get("testType") || ""),
      receivedDate: String(fd.get("receivedDate") || ""),
      testingDate: String(fd.get("testingDate") || ""),
      notes: String(fd.get("notes") || ""),
      testRows: rows,
    } as any;

    const fileProduk = fd.get("attachmentProduk") as File | null;
    const filePengujian = fd.get("attachmentPengujian") as File | null;

    startTransition(async () => {
      const getBase64 = async (f: File | null) => {
        if (!f || f.size === 0) return undefined;
        const arrayBuffer = await f.arrayBuffer();
        return `data:${f.type};base64,${Buffer.from(arrayBuffer).toString("base64")}`;
      };

      try {
        if (fileProduk && fileProduk.size > 0) input.attachmentProduk = await getBase64(fileProduk);
        if (filePengujian && filePengujian.size > 0) input.attachmentPengujian = await getBase64(filePengujian);
      } catch (err) {
        alert("Gagal membaca file lampiran.");
        return;
      }

      const result = await updateLhuAction(doc.id, input);
      if (result?.success) {
        router.push(`/lhu/${doc.id}/review`);
        router.refresh();
      } else {
        alert(result?.error || "Gagal menyimpan perubahan.");
      }
    });
  };

  // Map the DB document to the format GeneralInfoForm expects
  const defaultValues = {
    customer: doc.customer?.companyName ?? doc.customer ?? "",
    projectName: doc.projectName ?? "",
    projectAddress: doc.projectAddress ?? "",
    referenceNumber: doc.referenceNumber ?? "",
    concreteType: doc.concreteType ?? "silinder",
    testType: doc.testType ?? "Kuat Tekan Beton",
    receivedDate:
      doc.receivedDate instanceof Date
        ? doc.receivedDate.toISOString().split("T")[0]
        : String(doc.receivedDate ?? "").split("T")[0],
    testingDate:
      doc.testingDate instanceof Date
        ? doc.testingDate.toISOString().split("T")[0]
        : String(doc.testingDate ?? "").split("T")[0],
    notes: doc.notes ?? "",
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 pb-20">
      <Link
        href="/lhu"
        className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors bg-white/50 px-3 py-1.5 rounded-full border shadow-sm w-fit backdrop-blur-sm"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Kembali ke Data LHU
      </Link>

      <PageHeader
        title={`Edit Draft LHU — ${doc.documentCode}`}
        description="Perbaiki data Laporan Hasil Uji. Setelah disimpan, lanjutkan ke halaman Input Hasil untuk memperbaiki data uji."
      />

      <GeneralInfoForm defaultValues={defaultValues} />

      <div className="mt-8 mb-4">
        <TestResultsForm
          rows={rows}
          onAddRow={addRow}
          onRemoveRow={removeRow}
          onUpdateRow={updateRow}
        />
      </div>

      <div className="mt-8 mb-4">
        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-4 border-b pb-2">
          Lampiran Pendukung
        </h2>
        <AttachmentForm />
        <p className="text-sm text-yellow-600 dark:text-yellow-500 mt-2 bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-md border border-yellow-200 dark:border-yellow-800">
          <strong>Perhatian:</strong> Mengunggah gambar baru di atas akan langsung menimpa gambar lama yang telah tersimpan. Kosongkan jika tidak ingin mengubah gambar.
        </p>
      </div>

      <div className="flex items-center justify-end gap-4 border-t border-slate-200 pt-6 mt-8">
        <Button
          variant="outline"
          size="lg"
          type="button"
          className="rounded-xl px-8"
          onClick={() => router.push(`/lhu/${doc.id}`)}
        >
          Batal
        </Button>
        <Button
          size="lg"
          type="submit"
          disabled={isPending}
          className="rounded-xl px-8 bg-indigo-600 hover:bg-indigo-700 shadow-md"
        >
          {isPending ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Menyimpan...</>
          ) : (
            <><Save className="mr-2 h-4 w-4" /> Simpan Perubahan</>
          )}
        </Button>
      </div>
    </form>
  );
}
