"use server";

import { revalidatePath } from "next/cache";
import { requireSession } from "@/lib/auth/session";
import { assertPermission } from "@/lib/auth/rbac";
import {
  updateLhuDraft,
  getLhuDocumentById,
  upsertResultRows,
  setLhuStatus,
  ResultRowInput,
} from "@/lib/db/queries/lhu";
import { upsertCustomer } from "@/lib/db/queries/customers";
import { insertAuditLog } from "@/lib/db/queries/audit";
import { lhuAttachments, lhuResultRows } from "@/lib/db/schema";
import { db } from "@/lib/db";
import fs from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { eq, and } from "drizzle-orm";
import { TestRow } from "@/components/lhu/test-results-form";

async function saveBase64Image(base64Data: string, prefix: string): Promise<string> {
  if (!base64Data.startsWith("data:image")) return base64Data; // Already a URL / string

  const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
  if (!matches || matches.length !== 3) {
    throw new Error('Invalid base64 string');
  }

  const type = matches[1];
  const data = Buffer.from(matches[2], 'base64');
  let extension = "jpg";
  if (type === "image/png") extension = "png";
  if (type === "image/jpeg" || type === "image/jpg") extension = "jpg";

  const fileName = `${prefix}-${randomUUID()}.${extension}`;
  const dirPath = path.join(process.cwd(), "public", "uploads", "lhu");
  
  await fs.mkdir(dirPath, { recursive: true });
  await fs.writeFile(path.join(dirPath, fileName), data);
  
  return `/uploads/lhu/${fileName}`;
}

export interface UpdateLhuInput {
  customer: string;
  projectName: string;
  projectAddress: string;
  referenceNumber: string;
  concreteType: string;
  testType: string;
  receivedDate: string;
  testingDate: string;
  notes?: string;
  attachmentProduk?: string;
  attachmentPengujian?: string;
  testRows?: TestRow[];
}

export async function updateLhuAction(id: string, input: UpdateLhuInput) {
  const session = await requireSession();
  assertPermission(session, "editDraft");

  const doc = await getLhuDocumentById(id);
  if (!doc) return { success: false, error: "Dokumen tidak ditemukan." };

  if (doc.status !== "draft" && doc.status !== "revisi") {
    return { success: false, error: "Hanya dokumen berstatus draft atau revisi yang bisa diedit." };
  }

  const customer = await upsertCustomer({ companyName: input.customer.trim() });
  const concreteType =
    input.concreteType?.toLowerCase().includes("kubus") ? "kubus" : "silinder";

  await updateLhuDraft(id, {
    customerId: customer.id,
    projectName: input.projectName.trim(),
    projectAddress: input.projectAddress.trim(),
    referenceNumber: input.referenceNumber.trim(),
    testType: input.testType.trim(),
    concreteType,
    receivedDate: new Date(input.receivedDate),
    testingDate: new Date(input.testingDate),
    notes: input.notes?.trim(),
    updatedByUserId: session.id,
  });

  const now = new Date();

  // Handle Attachments
  if (input.attachmentProduk || input.attachmentPengujian) {
    const now = new Date();

    if (input.attachmentProduk) {
      try {
        const url = await saveBase64Image(input.attachmentProduk, "produk");
        await db.delete(lhuAttachments).where(
          and(eq(lhuAttachments.lhuDocumentId, id), eq(lhuAttachments.category, "produk"))
        );
        await db.insert(lhuAttachments).values({
          id: randomUUID(),
          lhuDocumentId: id,
          category: "produk" as const,
          fileUrl: url,
          fileName: "gambar_produk.jpg",
          createdAt: now,
          updatedAt: now,
        });
      } catch (e) {
        console.error("Gagal update lampiran produk", e);
      }
    }

    if (input.attachmentPengujian) {
      try {
        const url = await saveBase64Image(input.attachmentPengujian, "pengujian");
        await db.delete(lhuAttachments).where(
          and(eq(lhuAttachments.lhuDocumentId, id), eq(lhuAttachments.category, "pengujian"))
        );
        await db.insert(lhuAttachments).values({
          id: randomUUID(),
          lhuDocumentId: id,
          category: "pengujian" as const,
          fileUrl: url,
          fileName: "gambar_pengujian.jpg",
          createdAt: now,
          updatedAt: now,
        });
      } catch (e) {
        console.error("Gagal update lampiran pengujian", e);
      }
    }
  }

  // Handle Result Rows: Delete existing ones and re-insert the provided array
  await db.delete(lhuResultRows).where(eq(lhuResultRows.lhuDocumentId, id));
  
  const rowsToInsert = input.testRows?.filter(r => r.kodeSampel.trim()).map((r, idx) => ({
    id: randomUUID(),
    lhuDocumentId: id,
    rowNumber: idx + 1,
    sampleCode: r.kodeSampel.trim(),
    castingDate: r.tanggalBuat ? new Date(r.tanggalBuat) : now,
    testingDate: r.tanggalTest ? new Date(r.tanggalTest) : now,
    ageDays: parseInt(r.umur) || 0,
    weight: r.berat || null,
    dimension: r.ukuran || null,
    maxLoad: r.tekananMaksimum || null,
    compressiveStrength: r.teganganHancurMpa || null,
    failurePattern: r.polaHancur || null,
    remarks: r.keterangan || null,
    analystName: null,
    createdAt: now,
    updatedAt: now,
  })) || [];

  if (rowsToInsert.length > 0) {
    await db.insert(lhuResultRows).values(rowsToInsert as any);
  }

  await insertAuditLog({
    userId: session.id,
    action: "edit_document",
    entityType: "lhu_documents",
    entityId: id,
    metadata: { customer: customer.companyName },
  });

  revalidatePath("/lhu");
  revalidatePath(`/lhu/${id}`);
  revalidatePath(`/lhu/${id}/edit`);

  return { success: true };
}
