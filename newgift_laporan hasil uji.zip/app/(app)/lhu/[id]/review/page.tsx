import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, MessageSquareText } from "lucide-react";
import { getLhuDocumentById } from "@/lib/db/queries/lhu";
import { PageHeader } from "@/components/shared/page-header";
import { Card } from "@/components/ui/card";
import { ResultTable } from "@/components/lhu/result-table";
import { AttachmentGallery } from "@/components/lhu/attachment-gallery";
import { ReviewHeaderActions, ReviewPanelActions } from "@/components/lhu/review-actions";

export default async function ReviewQaPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const doc = await getLhuDocumentById(id);
  if (!doc) return notFound();

  const customerName = doc.customer?.companyName ?? "—";

  const resultRows = doc.resultRows.map((r) => ({
    id: r.id,
    rowNumber: r.rowNumber,
    sampleCode: r.sampleCode,
    castingDate: r.castingDate.toISOString().split("T")[0],
    testingDate: r.testingDate.toISOString().split("T")[0],
    ageDays: r.ageDays,
    weight: r.weight ?? "—",
    dimension: r.dimension ?? "—",
    maxLoad: r.maxLoad ?? "—",
    compressiveStrength: r.compressiveStrength ?? "—",
    failurePattern: r.failurePattern ?? "—",
    remarks: r.remarks ?? "",
    analystName: r.analystName ?? "—",
  }));

  const attachments = doc.attachments.map((a) => ({
    id: a.id,
    category: a.category,
    fileName: a.fileName,
    caption: a.caption ?? "",
    fileUrl: a.fileUrl,
  }));

  return (
    <div className="space-y-6 pb-10">
      <Link
        href="/lhu"
        className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors bg-white/50 px-3 py-1.5 rounded-full border shadow-sm w-fit backdrop-blur-sm"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Kembali ke Data LHU
      </Link>

      <PageHeader
        title={`Review QA — ${doc.documentCode}`}
        description="Halaman review untuk QA atau Supervisor: cek ringkasan dokumen, tabel hasil, lampiran, histori perubahan, dan masukkan catatan."
        actions={<ReviewHeaderActions id={doc.id} />}
      />

      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card className="bg-white/85 dark:bg-slate-900/80 dark:border-slate-800">
          <div className="text-lg font-semibold">Summary Dokumen</div>
          <div className="mt-5 grid gap-5 md:grid-cols-2">
            <div>
              <div className="text-sm text-muted-foreground">Customer</div>
              <div className="mt-1 font-medium">{customerName}</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Nama Proyek</div>
              <div className="mt-1 font-medium">{doc.projectName}</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Nomor Referensi</div>
              <div className="mt-1 font-medium">{doc.referenceNumber}</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Acuan</div>
              <div className="mt-1 font-medium">
                {doc.concreteType === "silinder" ? "Beton Silinder" : "Beton Kubus"}
              </div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Tanggal Terima</div>
              <div className="mt-1 font-medium">
                {doc.receivedDate.toLocaleDateString("id-ID")}
              </div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Tanggal Uji</div>
              <div className="mt-1 font-medium">
                {doc.testingDate.toLocaleDateString("id-ID")}
              </div>
            </div>
            <div className="md:col-span-2">
              <div className="text-sm text-muted-foreground">Jumlah Benda Uji</div>
              <div className="mt-1 font-medium">{doc.resultRows.length} sampel</div>
            </div>
          </div>
        </Card>

        <Card className="bg-white/85 dark:bg-slate-900/80 dark:border-slate-800">
          <div className="mb-4 flex items-center gap-2 text-lg font-semibold">
            <MessageSquareText className="h-5 w-5 text-primary" />
            Panel Komentar QA
          </div>
          <ReviewPanelActions id={doc.id} currentStatus={doc.status} />
        </Card>
      </div>

      <div className="space-y-4">
        <div className="text-xl font-semibold">Tabel Hasil Uji</div>
        <ResultTable rows={resultRows} />
      </div>

      <div className="space-y-4">
        <div className="text-xl font-semibold">Lampiran</div>
        <AttachmentGallery attachments={attachments} />
      </div>
    </div>
  );
}
