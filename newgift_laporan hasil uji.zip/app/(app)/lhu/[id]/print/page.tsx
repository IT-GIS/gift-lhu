import { notFound } from "next/navigation";
import { getLhuDocumentById } from "@/lib/db/queries/lhu";
import { getSettings } from "@/lib/db/queries/settings";
import { formatDate, getConcreteTypeLabel } from "@/lib/utils";
import { QRCodeSVG } from "qrcode.react";

export default async function PrintLhuPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const [doc, settings] = await Promise.all([
    getLhuDocumentById(id),
    getSettings(["company_name", "company_address", "verification_base_url", "document_footer", "logo_url"]),
  ]);

  if (!doc) return notFound();

  const appUrl = settings.verification_base_url || process.env.APP_URL || "http://localhost:3000";
  const companyName = settings.company_name || "Laboratorium";
  const companyAddress = settings.company_address || "";
  const documentFooter = settings.document_footer || "";
  const activeToken = doc.activeToken?.publicToken;
  const verifyUrl = activeToken ? `${appUrl}/verify/${activeToken}` : appUrl;
  const customerName = doc.customer?.companyName ?? "—";

  return (
    <main className="mx-auto max-w-5xl bg-white p-10 text-slate-900 print:p-6">
      {/* Letterhead */}
      <div className="mb-8 flex items-start justify-between border-b border-slate-300 pb-6">
        <div>
          {settings.logo_url && (
            <img
              src={settings.logo_url}
              alt="Logo"
              className="mb-3 h-12 object-contain"
            />
          )}
          <div className="text-xl font-bold text-slate-900">{companyName}</div>
          <div className="mt-0.5 text-sm text-slate-600">{companyAddress}</div>
          <div className="mt-4 text-sm font-semibold">
            Laporan Hasil Uji Kuat Tekan Beton
          </div>
          <div className="text-sm">
            Nomor LHU:{" "}
            <span className="font-semibold">
              {doc.lhuNumber || "Akan di-generate saat publish"}
            </span>
          </div>
          <div className="text-sm text-slate-600">
            Acuan: {getConcreteTypeLabel(doc.concreteType)}
          </div>
        </div>
        <div className="flex flex-col items-center gap-2">
          {activeToken ? (
            <>
              <div className="border border-slate-200 p-2 rounded">
                <QRCodeSVG value={verifyUrl} size={88} />
              </div>
              <div className="text-[9px] text-slate-500 text-center max-w-[100px]">
                Scan untuk verifikasi
              </div>
            </>
          ) : (
            <div className="text-xs text-slate-400 italic text-center max-w-[100px]">
              QR tersedia setelah publish
            </div>
          )}
        </div>
      </div>

      {/* Document Info */}
      <div className="grid gap-3 md:grid-cols-2 text-sm mb-6">
        <div>
          <span className="font-semibold">Pelanggan:</span> {customerName}
        </div>
        <div>
          <span className="font-semibold">Nama Proyek:</span> {doc.projectName}
        </div>
        <div>
          <span className="font-semibold">Alamat Proyek:</span>{" "}
          {doc.projectAddress}
        </div>
        <div>
          <span className="font-semibold">Nomor Referensi:</span>{" "}
          {doc.referenceNumber}
        </div>
        <div>
          <span className="font-semibold">Tanggal Terima:</span>{" "}
          {formatDate(doc.receivedDate.toISOString())}
        </div>
        <div>
          <span className="font-semibold">Tanggal Uji:</span>{" "}
          {formatDate(doc.testingDate.toISOString())}
        </div>
      </div>

      {/* Results Table */}
      {doc.resultRows.length > 0 ? (
        <table className="mt-4 w-full border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100">
              {[
                "No",
                "Kode",
                "Tgl Buat",
                "Tgl Uji",
                "Umur",
                "Berat (kg)",
                "Ukuran",
                "Beban (kN)",
                "Kuat Tekan (MPa)",
                "Pola Hancur",
                "Keterangan",
                "Analis",
              ].map((h) => (
                <th key={h} className="border border-slate-300 px-2 py-1.5 text-left font-semibold">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {doc.resultRows.map((row) => (
              <tr key={row.id} className="even:bg-slate-50">
                <td className="border border-slate-300 px-2 py-1">{row.rowNumber}</td>
                <td className="border border-slate-300 px-2 py-1">{row.sampleCode}</td>
                <td className="border border-slate-300 px-2 py-1">
                  {formatDate(row.castingDate.toISOString())}
                </td>
                <td className="border border-slate-300 px-2 py-1">
                  {formatDate(row.testingDate.toISOString())}
                </td>
                <td className="border border-slate-300 px-2 py-1">{row.ageDays}</td>
                <td className="border border-slate-300 px-2 py-1">{row.weight ?? "—"}</td>
                <td className="border border-slate-300 px-2 py-1">{row.dimension ?? "—"}</td>
                <td className="border border-slate-300 px-2 py-1">{row.maxLoad ?? "—"}</td>
                <td className="border border-slate-300 px-2 py-1 font-semibold">
                  {row.compressiveStrength ?? "—"}
                </td>
                <td className="border border-slate-300 px-2 py-1">{row.failurePattern ?? "—"}</td>
                <td className="border border-slate-300 px-2 py-1">{row.remarks ?? ""}</td>
                <td className="border border-slate-300 px-2 py-1">{row.analystName ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="mt-6 text-sm text-slate-500 italic">
          Belum ada hasil uji yang diinput.
        </div>
      )}

      {/* Footer */}
      {documentFooter && (
        <div className="mt-10 border-t border-slate-200 pt-4 text-xs text-slate-500">
          {documentFooter}
        </div>
      )}

      <div className="mt-6 text-xs text-slate-400">
        Dicetak pada: {new Date().toLocaleString("id-ID")}
        {activeToken && ` · Token: ${activeToken}`}
      </div>
    </main>
  );
}
