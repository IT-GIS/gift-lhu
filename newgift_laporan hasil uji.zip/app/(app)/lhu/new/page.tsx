"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Save, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { GeneralInfoForm } from "@/components/lhu/general-info-form";
import { AttachmentForm } from "@/components/lhu/attachment-form";
import { TestResultsForm, TestRow } from "@/components/lhu/test-results-form";
import { createLhuAction, CreateLhuInput } from "./actions";

function createEmptyRow(): TestRow {
  return {
    id: Math.random().toString(36).substr(2, 9),
    kodeSampel: "",
    tanggalBuat: "",
    tanggalTest: "",
    berat: "",
    umur: "",
    ukuran: "",
    tekananMaksimum: "",
    teganganHancurMpa: "",
    teganganHancurOther: "",
    polaHancur: "",
    keterangan: "",
  };
}

export default function CreateLhuPage() {
  const router = useRouter();
  const [rows, setRows] = useState<TestRow[]>([createEmptyRow()]);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const addRow = () => setRows([...rows, createEmptyRow()]);
  const removeRow = (id: string) => {
    if (rows.length > 1) setRows(rows.filter((r) => r.id !== id));
  };
  const updateRow = (id: string, field: keyof TestRow, value: string) => {
    setRows(rows.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
  };

  const handleSave = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);

    const input: CreateLhuInput = {
      customer: String(fd.get("customer") || ""),
      projectName: String(fd.get("projectName") || ""),
      projectAddress: String(fd.get("projectAddress") || ""),
      referenceNumber: String(fd.get("referenceNumber") || ""),
      concreteType: String(fd.get("concreteType") || ""),
      testType: String(fd.get("testType") || ""),
      receivedDate: String(fd.get("receivedDate") || ""),
      testingDate: String(fd.get("testingDate") || ""),
      testRows: rows,
    };

    // Extract files if present
    const fileProduk = fd.get("attachmentProduk") as File | null;
    const filePengujian = fd.get("attachmentPengujian") as File | null;

    if (!input.customer || !input.projectName || !input.receivedDate || !input.testingDate) {
      setError("Nama pelanggan, proyek, dan tanggal wajib diisi.");
      return;
    }

    setError(null);
    startTransition(async () => {
      // Convert files to base64
      const getBase64 = async (f: File | null) => {
        if (!f || f.size === 0) return undefined;
        const arrayBuffer = await f.arrayBuffer();
        return `data:${f.type};base64,${Buffer.from(arrayBuffer).toString("base64")}`;
      };

      try {
        if (fileProduk && fileProduk.size > 0) input.attachmentProduk = await getBase64(fileProduk);
        if (filePengujian && filePengujian.size > 0) input.attachmentPengujian = await getBase64(filePengujian);
      } catch (err) {
        setError("Gagal membaca file lampiran.");
        return;
      }

      const result = await createLhuAction(input);
      if (result?.success) {
        router.push(`/lhu/${result.id}/review`);
      } else {
        setError("Gagal membuat draft. Silakan coba lagi.");
      }
    });
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 pb-20">
      <PageHeader
        title="Input Data LHU Baru"
        description="Lengkapi informasi pelanggan dan parameter pengujian. Setelah draft dibuat, Anda dapat mengisi hasil uji di halaman berikutnya."
      />

      {error && (
        <div className="rounded-xl bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-sm font-medium">
          {error}
        </div>
      )}

      <GeneralInfoForm />

      <div className="mt-8 mb-4">
        <TestResultsForm
          rows={rows}
          onAddRow={addRow}
          onRemoveRow={removeRow}
          onUpdateRow={updateRow}
        />
      </div>

      <div className="mt-8 mb-4">
        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-4 border-b pb-2">
          Lampiran Pendukung
        </h2>
        <AttachmentForm />
      </div>

      <div className="flex items-center justify-end gap-4 border-t border-slate-200 pt-6 mt-8">
        <Button
          variant="outline"
          size="lg"
          type="button"
          className="rounded-xl px-8"
          onClick={() => router.push("/lhu")}
        >
          Batal
        </Button>
        <Button
          size="lg"
          type="submit"
          disabled={isPending}
          className="rounded-xl px-8 bg-indigo-600 hover:bg-indigo-700 shadow-md"
        >
          {isPending ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Menyimpan...</>
          ) : (
          <><Save className="mr-2 h-4 w-4" /> Simpan Draft</>
        )}
        </Button>
      </div>
    </form>
  );
}
