"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/shared/page-header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";
import { ClipboardCheck, Loader2 } from "lucide-react";
import { getReviewDocuments } from "./actions";

type ReviewDoc = Awaited<ReturnType<typeof getReviewDocuments>>[number];

/**
 * ReviewQAListPage
 * Halaman daftar dokumen LHU yang menunggu review QA.
 * Menggunakan server action untuk mengambil data segar setiap kali halaman dimuat,
 * sehingga draft baru yang baru dibuat langsung muncul.
 */
export default function ReviewQAListPage() {
  const [reviewDocs, setReviewDocs] = useState<ReviewDoc[]>([]);
  const [loading, setLoading] = useState(true);

  // Ambil data review docs setiap kali halaman dimount
  useEffect(() => {
    getReviewDocuments().then((docs) => {
      setReviewDocs(docs);
      setLoading(false);
    });
  }, []);

  return (
    <div className="space-y-8 pb-20">
      <PageHeader
        title="Daftar Review QA"
        description="Daftar dokumen Laporan Hasil Uji (LHU) yang sedang menunggu validasi dan peninjauan akhir oleh bagian Quality Assurance."
      />

      <Card className="neu-card rounded-2xl p-1 overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-sm text-left">
            <thead className="text-slate-700 dark:text-slate-300 uppercase text-xs font-semibold"
                   style={{ borderBottom: "1px solid var(--neu-shadow-a)" }}>
              <tr>
                <th className="px-5 py-4 whitespace-nowrap">Kode Draft / LHU</th>
                <th className="px-5 py-4 whitespace-nowrap">Perusahaan</th>
                <th className="px-5 py-4 whitespace-nowrap">Acuan / Jenis Uji</th>
                <th className="px-5 py-4 whitespace-nowrap">Tanggal Test</th>
                <th className="px-5 py-4 whitespace-nowrap text-center">Status</th>
                <th className="px-5 py-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-muted-foreground text-sm">
                    <Loader2 className="mx-auto h-5 w-5 animate-spin mb-2" />
                    Memuat data...
                  </td>
                </tr>
              ) : reviewDocs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-muted-foreground text-sm">
                    Tidak ada draft LHU yang membutuhkan review saat ini.
                  </td>
                </tr>
              ) : (
                reviewDocs.map((doc) => (
                  <tr key={doc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-5 py-4">
                      <div className="font-semibold text-slate-800 dark:text-slate-100">{doc.documentCode}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{doc.lhuNumber || "-"}</div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="font-medium text-slate-800 dark:text-slate-100">{doc.customer}</div>
                      <div className="text-xs text-muted-foreground mt-0.5 max-w-[200px] truncate" title={doc.projectName}>{doc.projectName}</div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="font-medium text-slate-700 dark:text-slate-200">{doc.concreteType.toUpperCase()}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{doc.testType}</div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="text-slate-700 dark:text-slate-200 font-medium">{formatDate(doc.testingDate)}</div>
                    </td>
                    <td className="px-5 py-4 text-center">
                      <Badge className="bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800 font-medium px-2.5 py-0.5">
                        Menunggu Review
                      </Badge>
                    </td>
                    <td className="px-5 py-4 text-center">
                      <Button asChild size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-xs px-4 h-8">
                        <Link href={`/lhu/${doc.id}/review`}>
                          <ClipboardCheck className="mr-1.5 h-3.5 w-3.5" />
                          Detail Review
                        </Link>
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
