import { notFound } from "next/navigation";
import { AlertTriangle, CheckCircle2, ShieldAlert, FileSearch } from "lucide-react";
import { getLhuDocumentById } from "@/lib/db/queries/lhu";
import { Card } from "@/components/ui/card";
import { formatDate, getConcreteTypeLabel } from "@/lib/utils";

/**
 * STANDALONE PUBLIC ROUTE FOR EXTERNAL CLIENTS (QR CODE TARGET)
 * URL: /scan/[lhuId]
 * 
 * Route ini digunakan untuk verifikasi lewat QR code lama yang mencantumkan lhuId.
 * Fetch dokumen langsung dari DB berdasarkan ID.
 */
export default async function PublicClientScanPage({
  params,
}: {
  params: Promise<{ lhuId: string }>;
}) {
  const { lhuId } = await params;
  const doc = await getLhuDocumentById(lhuId);

  if (!doc) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-8 sm:px-6 md:py-16 font-sans">
        <div className="mx-auto max-w-2xl">
          <Card className="bg-white p-8 md:p-12 text-center shadow-xl border-t-8 border-t-rose-500 rounded-2xl">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-rose-50 text-rose-500 mb-6">
              <AlertTriangle className="h-10 w-10" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-800">LHU TIDAK DITEMUKAN</h1>
            <p className="mt-4 text-lg text-slate-600 leading-relaxed">
              Sistem gagal menemukan Dokumen Laporan Hasil Uji dengan identitas yang tercantum di QR code ini.
            </p>
            <div className="mt-10 border-t border-slate-100 pt-8 text-sm text-slate-500 font-medium">
              Sistem Validasi LHU © PT. Global Inspeksi Forensik Teknik
            </div>
          </Card>
        </div>
      </main>
    );
  }

  const isValid = doc.status === "published";
  const isRevoked = doc.status === "revoked";
  const customerName = doc.customer?.companyName ?? "—";

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 sm:px-6 sm:py-12 md:py-16 font-sans">
      <div className="mx-auto max-w-4xl space-y-8">
        {/* PUBLIC HEADER */}
        <div className="flex flex-col items-center justify-center text-center space-y-3 mb-10">
          <div className="flex items-center justify-center h-14 w-14 rounded-full bg-indigo-600 text-white shadow-lg shadow-indigo-200 mb-2">
            <FileSearch className="h-6 w-6" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">Verifikasi Keaslian LHU</h1>
          <p className="text-slate-500 max-w-lg font-medium">Halaman Resmi Verifikasi Dokumen Laporan Hasil Uji Beton</p>
        </div>

        {/* MAIN DOCUMENT CARD */}
        <Card className="bg-white p-6 sm:p-10 shadow-xl border-slate-200/60 rounded-3xl overflow-hidden relative">
          {/* Status Banner */}
          <div className={`absolute top-0 left-0 w-full h-2 ${isValid ? "bg-emerald-500" : isRevoked ? "bg-rose-500" : "bg-amber-500"}`} />

          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6 mb-8 pt-2">
            <div>
              <div className="text-xs uppercase tracking-[0.2em] font-bold text-slate-400 mb-2">Status Registrasi</div>
              {isValid ? (
                <div className="inline-flex items-center gap-2 text-emerald-700 bg-emerald-50 px-4 py-2 rounded-full border border-emerald-100 shadow-sm">
                  <CheckCircle2 className="h-5 w-5" />
                  <span className="font-bold tracking-wide">DOKUMEN VALID</span>
                </div>
              ) : isRevoked ? (
                <div className="inline-flex items-center gap-2 text-rose-700 bg-rose-50 px-4 py-2 rounded-full border border-rose-100 shadow-sm">
                  <ShieldAlert className="h-5 w-5" />
                  <span className="font-bold tracking-wide">DOKUMEN TIDAK SAH (REVOKED)</span>
                </div>
              ) : (
                <div className="inline-flex items-center gap-2 text-amber-700 bg-amber-50 px-4 py-2 rounded-full border border-amber-100 shadow-sm">
                  <AlertTriangle className="h-5 w-5" />
                  <span className="font-bold tracking-wide">DOKUMEN DRAFT / PROSES</span>
                </div>
              )}
            </div>
            <div className="sm:text-right">
              <div className="text-xs uppercase tracking-[0.2em] font-bold text-slate-400 mb-1">Nomor Seri LHU</div>
              <div className="text-xl sm:text-2xl font-black text-slate-800">{doc.lhuNumber || "Dalam Proses"}</div>
            </div>
          </div>

          {!isValid && (
            <div className={`mb-8 p-5 rounded-2xl border ${isRevoked ? "bg-rose-50 border-rose-100 text-rose-800" : "bg-amber-50 border-amber-100 text-amber-800"}`}>
              <h4 className="font-bold mb-1">{isRevoked ? "Mengapa Dokumen Ini Tidak Sah?" : "Peringatan Dokumen"}</h4>
              <p className="text-sm">
                {isRevoked
                  ? doc.revokedReason
                  : "Dokumen ini belum berstatus diterbitkan secara publik. Hasil uji bersifat sementara."}
              </p>
            </div>
          )}

          {/* DETAIL GRID */}
          <div className="grid gap-x-6 gap-y-6 sm:grid-cols-2 lg:grid-cols-3 bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Nama Pelanggan</div>
              <div className="font-semibold text-slate-800">{customerName}</div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Nama Proyek</div>
              <div className="font-semibold text-slate-800">{doc.projectName}</div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Parameter Uji</div>
              <div className="font-semibold text-slate-800">{doc.testType}</div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Bentuk Benda Uji</div>
              <div className="font-semibold text-slate-800">{getConcreteTypeLabel(doc.concreteType)}</div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Tanggal Diuji</div>
              <div className="font-semibold text-slate-800">{formatDate(doc.testingDate.toISOString())}</div>
            </div>
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Tanggal Publish LHU</div>
              <div className="font-semibold text-slate-800">
                {doc.publishedAt ? formatDate(doc.publishedAt.toISOString()) : "—"}
              </div>
            </div>
          </div>

          <div className="mt-10 border-t border-slate-100 pt-8" />

          {/* Test Results Table */}
          <h3 className="text-lg sm:text-xl font-bold mb-6 text-slate-900">Rekapitulasi Hasil Pengujian Kuat Tekan</h3>
          {doc.resultRows.length > 0 ? (
            <div className="overflow-x-auto w-full rounded-2xl border border-slate-200 bg-white shadow-sm mb-10">
              <table className="w-full text-sm text-left">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 uppercase text-[11px] font-bold tracking-wider">
                  <tr>
                    <th className="px-4 py-4 text-center border-r border-slate-100">Kode Sampel</th>
                    <th className="px-4 py-4 text-center border-r border-slate-100">Usia Beton (Hari)</th>
                    <th className="px-4 py-4 text-center border-r border-slate-100">Beban Maks. (kN)</th>
                    <th className="px-4 py-4 text-center border-r border-slate-100 bg-indigo-50/50 text-indigo-900">Kuat Tekan (MPa)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {doc.resultRows.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3.5 border-r border-slate-100 font-bold text-slate-700 text-center">{row.sampleCode}</td>
                      <td className="px-4 py-3.5 text-center border-r border-slate-100 text-slate-600">{row.ageDays}</td>
                      <td className="px-4 py-3.5 text-center border-r border-slate-100 text-slate-600 font-medium">{row.maxLoad ?? "—"}</td>
                      <td className="px-4 py-3.5 text-center border-r border-slate-100 font-black text-indigo-700 text-base bg-indigo-50/30">
                        {row.compressiveStrength ?? "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 text-slate-500 italic p-6 rounded-2xl text-center text-sm mb-10">
              Data hasil pengujian belum ditambahkan pada laporan ini.
            </div>
          )}

          <div className="rounded-2xl bg-slate-800 text-white p-6 sm:p-8 flex flex-col md:flex-row items-center gap-6 justify-between">
            <div className="shrink-0 flex items-center justify-center p-3 bg-white/10 rounded-full h-16 w-16 backdrop-blur-sm">
              <CheckCircle2 className="h-8 w-8 text-emerald-400" />
            </div>
            <div className="flex-1 text-center md:text-left">
              <h4 className="font-bold text-lg mb-2 text-white/90">Pusat Verifikasi Laboratorium</h4>
              <p className="text-sm text-slate-300 leading-relaxed font-medium">
                Halaman digital ini adalah representasi tervalidasi dari Dokumen Fisik Laporan Hasil Uji (LHU) Beton.
                Segala upaya pemalsuan di luar data yang tercantum dinyatakan{" "}
                <strong>tidak sah</strong>.
              </p>
            </div>
          </div>
        </Card>

        <div className="text-center pb-20 mt-12 text-slate-400 text-sm font-medium">
          Diterbitkan & Dilindungi Sistem Laboratorium © 2026
        </div>
      </div>
    </main>
  );
}
