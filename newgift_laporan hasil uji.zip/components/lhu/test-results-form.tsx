import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Trash2 } from "lucide-react";

export interface TestRow {
  id: string;
  kodeSampel: string;
  tanggalBuat: string;
  tanggalTest: string;
  berat: string;
  umur: string;
  ukuran: string;
  tekananMaksimum: string;
  teganganHancurMpa: string;
  teganganHancurOther: string;
  polaHancur: string;
  keterangan: string;
}

interface TestResultsFormProps {
  rows: TestRow[];
  onAddRow: () => void;
  onRemoveRow: (id: string) => void;
  onUpdateRow: (id: string, field: keyof TestRow, value: string) => void;
}

export function TestResultsForm({ rows, onAddRow, onRemoveRow, onUpdateRow }: TestResultsFormProps) {
  return (
    <Card className="bg-white/85 dark:bg-slate-900/80 p-6 shadow-sm border-slate-200 dark:border-slate-800 overflow-hidden">
      <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4 dark:border-slate-700">
        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100">Tabel Rekam Data Pengujian</h2>
        <Button onClick={onAddRow} size="sm" className="bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all hover:shadow-md hover:-translate-y-0.5">
          <Plus className="mr-2 h-4 w-4" /> Tambah Baris Sampel
        </Button>
      </div>

      <div className="overflow-x-auto w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-sm">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700 uppercase text-xs font-semibold">
            <tr>
              <th className="px-3 py-4 text-center border-r border-slate-200 w-12">No.</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[120px]">Kode<br/>Sampel</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[110px]">Tanggal<br/>Buat</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[110px]">Tanggal<br/>Test</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[80px]">Berat<br/>(Kg)</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[80px]">Umur<br/>(Hari)</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[90px]">Ukuran<br/>(mm)</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[100px]">Tekanan<br/>Maksimum<br/>(kN)</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[100px]">Tegangan<br/>Hancur<br/>(Mpa)</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[100px]">Tegangan<br/>Hancur<br/>( kg/cm² )</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[100px]">Pola<br/>Hancur</th>
              <th className="px-3 py-4 text-center border-r border-slate-200 min-w-[120px]">Keterangan</th>
              <th className="px-2 py-4 text-center w-12">Hapus</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {rows.map((row, index) => (
              <tr key={row.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                <td className="px-2 py-2 text-center font-medium text-slate-500 border-r border-slate-100">{index + 1}</td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input value={row.kodeSampel} onChange={(e) => onUpdateRow(row.id, "kodeSampel", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none rounded-none w-full" placeholder="-" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="date" value={row.tanggalBuat} onChange={(e) => onUpdateRow(row.id, "tanggalBuat", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none px-1 rounded-none w-full" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="date" value={row.tanggalTest} onChange={(e) => onUpdateRow(row.id, "tanggalTest", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none px-1 rounded-none w-full" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="number" step="0.01" value={row.berat} onChange={(e) => onUpdateRow(row.id, "berat", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center rounded-none w-full" placeholder="0" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="number" value={row.umur} onChange={(e) => onUpdateRow(row.id, "umur", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center rounded-none w-full" placeholder="0" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input value={row.ukuran} onChange={(e) => onUpdateRow(row.id, "ukuran", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center rounded-none w-full" placeholder="-" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="number" step="0.01" value={row.tekananMaksimum} onChange={(e) => onUpdateRow(row.id, "tekananMaksimum", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center rounded-none w-full" placeholder="0" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="number" step="0.01" value={row.teganganHancurMpa} onChange={(e) => onUpdateRow(row.id, "teganganHancurMpa", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center font-semibold text-indigo-700 rounded-none w-full" placeholder="0" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input type="number" step="0.01" value={row.teganganHancurOther} onChange={(e) => onUpdateRow(row.id, "teganganHancurOther", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center font-semibold text-indigo-700 rounded-none w-full" placeholder="0" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input value={row.polaHancur} onChange={(e) => onUpdateRow(row.id, "polaHancur", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none text-center rounded-none w-full" placeholder="1-6" /></td>
                <td className="px-2 py-2 border-r border-slate-100 p-0"><Input value={row.keterangan} onChange={(e) => onUpdateRow(row.id, "keterangan", e.target.value)} className="h-10 text-xs bg-transparent border-0 ring-0 focus-visible:ring-1 shadow-none rounded-none w-full" placeholder="Catatan..." /></td>
                <td className="px-2 py-2 text-center p-0">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => onRemoveRow(row.id)}
                    disabled={rows.length === 1}
                    className="h-8 w-8 text-rose-500 hover:text-rose-700 hover:bg-rose-50 disabled:opacity-30 disabled:hover:bg-transparent transition-colors mx-auto block"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
