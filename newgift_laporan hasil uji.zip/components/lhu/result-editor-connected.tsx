"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { CopyPlus, Plus, Trash2, GripVertical, Save, Send, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { saveResultsAction, submitForReviewAction } from "@/app/(app)/lhu/[id]/results/actions";

export type EditableRow = {
  id: string;
  rowNumber: number;
  sampleCode: string;
  castingDate: string;
  testingDate: string;
  ageDays: string;
  weight: string;
  dimension: string;
  maxLoad: string;
  compressiveStrength: string;
  failurePattern: string;
  remarks: string;
  analystName: string;
};

function createEmptyRow(n: number): EditableRow {
  return {
    id: crypto.randomUUID(),
    rowNumber: n,
    sampleCode: "",
    castingDate: "",
    testingDate: "",
    ageDays: "",
    weight: "",
    dimension: "",
    maxLoad: "",
    compressiveStrength: "",
    failurePattern: "",
    remarks: "",
    analystName: "",
  };
}

interface Props {
  lhuDocumentId: string;
  initialRows: EditableRow[];
  currentStatus: string;
}

export function ResultEditorConnected({
  lhuDocumentId,
  initialRows,
  currentStatus,
}: Props) {
  const router = useRouter();
  const [rows, setRows] = useState<EditableRow[]>(
    initialRows.length > 0 ? initialRows : [createEmptyRow(1)]
  );
  const [isSaving, startSave] = useTransition();
  const [isSubmitting, startSubmit] = useTransition();
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const updateRow = (id: string, field: keyof EditableRow, value: string) => {
    setRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
    );
  };

  const addRow = () => {
    setRows((prev) => [...prev, createEmptyRow(prev.length + 1)]);
  };

  const duplicateRow = (id: string) => {
    setRows((prev) => {
      const target = prev.find((r) => r.id === id);
      if (!target) return prev;
      return [...prev, { ...target, id: crypto.randomUUID(), rowNumber: prev.length + 1 }];
    });
  };

  const removeRow = (id: string) => {
    setRows((prev) =>
      prev
        .filter((r) => r.id !== id)
        .map((r, i) => ({ ...r, rowNumber: i + 1 }))
    );
  };

  const averageStrength = useMemo(() => {
    const vals = rows
      .map((r) => parseFloat(r.compressiveStrength))
      .filter((v) => !isNaN(v));
    if (!vals.length) return 0;
    return vals.reduce((a, b) => a + b, 0) / vals.length;
  }, [rows]);

  const showMessage = (type: "success" | "error", text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 4000);
  };

  const handleSave = () => {
    startSave(async () => {
      const result = await saveResultsAction(lhuDocumentId, rows.map((r) => ({
        rowNumber: r.rowNumber,
        sampleCode: r.sampleCode,
        castingDate: r.castingDate,
        testingDate: r.testingDate,
        ageDays: parseInt(r.ageDays) || 0,
        weight: r.weight || null,
        dimension: r.dimension || null,
        maxLoad: r.maxLoad || null,
        compressiveStrength: r.compressiveStrength || null,
        failurePattern: r.failurePattern || null,
        remarks: r.remarks || null,
        analystName: r.analystName || null,
      })));

      if (result?.success) {
        showMessage("success", "Hasil uji berhasil disimpan.");
        router.refresh();
      } else {
        showMessage("error", result?.error || "Gagal menyimpan.");
      }
    });
  };

  const handleSubmitForReview = () => {
    startSubmit(async () => {
      // Save first, then submit
      const saveResult = await saveResultsAction(lhuDocumentId, rows.map((r) => ({
        rowNumber: r.rowNumber,
        sampleCode: r.sampleCode,
        castingDate: r.castingDate,
        testingDate: r.testingDate,
        ageDays: parseInt(r.ageDays) || 0,
        weight: r.weight || null,
        dimension: r.dimension || null,
        maxLoad: r.maxLoad || null,
        compressiveStrength: r.compressiveStrength || null,
        failurePattern: r.failurePattern || null,
        remarks: r.remarks || null,
        analystName: r.analystName || null,
      })));

      if (!saveResult?.success) {
        showMessage("error", saveResult?.error || "Gagal menyimpan sebelum submit.");
        return;
      }

      const submitResult = await submitForReviewAction(lhuDocumentId);
      if (submitResult?.success) {
        showMessage("success", "Dokumen berhasil dikirim ke QA Review!");
        setTimeout(() => router.push("/lhu"), 1200);
      } else {
        showMessage("error", submitResult?.error || "Gagal mengirim ke review.");
      }
    });
  };

  const FIELDS: { key: keyof EditableRow; label: string; type?: string }[] = [
    { key: "sampleCode", label: "Kode Benda Uji" },
    { key: "castingDate", label: "Tgl Pembuatan", type: "date" },
    { key: "testingDate", label: "Tgl Pengujian", type: "date" },
    { key: "ageDays", label: "Umur (hari)", type: "number" },
    { key: "weight", label: "Berat (kg)", type: "number" },
    { key: "dimension", label: "Ukuran" },
    { key: "maxLoad", label: "Beban Maks (kN)", type: "number" },
    { key: "compressiveStrength", label: "Kuat Tekan (MPa)", type: "number" },
    { key: "failurePattern", label: "Pola Hancur" },
    { key: "remarks", label: "Keterangan" },
    { key: "analystName", label: "Nama Analis" },
  ];

  return (
    <div className="space-y-5">
      {message && (
        <div className={`px-4 py-3 rounded-xl font-medium text-sm ${
          message.type === "success"
            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
            : "bg-red-50 text-red-700 border border-red-200"
        }`}>
          {message.text}
        </div>
      )}

      <Card className="bg-white/80 dark:bg-slate-900/80 dark:border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">Tabel Hasil Uji</div>
            <p className="text-sm text-muted-foreground">
              Tambah, duplikat, dan edit baris data uji. Simpan sebagai draft atau langsung kirim ke QA.
            </p>
          </div>
          {averageStrength > 0 && (
            <div className="rounded-2xl bg-primary/10 px-4 py-3 text-sm font-medium text-primary">
              Rata-rata kuat tekan: {averageStrength.toFixed(2)} MPa
            </div>
          )}
        </div>
      </Card>

      <Card className="overflow-hidden bg-white/85 dark:bg-slate-900/80 dark:border-slate-800 p-0">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1400px] text-sm">
            <thead className="sticky top-0 bg-muted/80 backdrop-blur">
              <tr className="border-b border-border text-left">
                <th className="px-3 py-3 font-medium text-muted-foreground w-8"></th>
                <th className="px-3 py-3 font-medium text-muted-foreground w-8">No</th>
                {FIELDS.map((f) => (
                  <th key={f.key} className="px-3 py-3 font-medium text-muted-foreground whitespace-nowrap">
                    {f.label}
                  </th>
                ))}
                <th className="px-3 py-3 font-medium text-muted-foreground">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-b border-border align-top hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="px-3 py-3 text-muted-foreground">
                    <GripVertical className="h-4 w-4" />
                  </td>
                  <td className="px-3 py-3 font-medium text-muted-foreground">{row.rowNumber}</td>
                  {FIELDS.map((f) => (
                    <td key={f.key} className="px-3 py-2">
                      <Input
                        type={f.type ?? "text"}
                        value={row[f.key] as string}
                        onChange={(e) => updateRow(row.id, f.key, e.target.value)}
                        className="h-8 text-sm min-w-[100px]"
                      />
                    </td>
                  ))}
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      <Button
                        variant="secondary"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => duplicateRow(row.id)}
                        title="Duplikat baris"
                      >
                        <CopyPlus className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => removeRow(row.id)}
                        disabled={rows.length === 1}
                        title="Hapus baris"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex flex-wrap items-center gap-3 border-t border-slate-200 dark:border-slate-700 pt-6">
        <Button variant="outline" onClick={addRow}>
          <Plus className="h-4 w-4" />
          Tambah Baris
        </Button>

        <div className="flex-1" />

        <Button
          variant="secondary"
          onClick={handleSave}
          disabled={isSaving || isSubmitting}
        >
          {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
          Simpan Draft
        </Button>

        <Button
          onClick={handleSubmitForReview}
          disabled={isSaving || isSubmitting}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
          Kirim ke Review QA
        </Button>
      </div>
    </div>
  );
}
