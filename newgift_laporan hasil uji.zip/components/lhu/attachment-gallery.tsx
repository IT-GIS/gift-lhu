import { Card } from "@/components/ui/card";
import { Image as ImageIcon } from "lucide-react";

/** Struktur data satu lampiran dokumen LHU. */
interface Attachment {
  id: string;
  category: string;
  fileName: string;
  caption: string;
  url?: string;
}

/** Menampilkan galeri lampiran (foto produk / foto pengujian) dalam grid. */
export function AttachmentGallery({ attachments }: { attachments: Attachment[] }) {
  if (!attachments.length) {
    return (
      <Card className="bg-white/80 dark:bg-slate-900/80 dark:border-slate-800">
        <div className="text-lg font-semibold dark:text-slate-100">Lampiran</div>
        <p className="mt-2 text-sm text-muted-foreground">
          Belum ada lampiran. Modul upload siap untuk drag-and-drop multiple image dengan caption dan reorder.
        </p>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {attachments.map((attachment) => (
        <Card key={attachment.id} className="bg-white/80 dark:bg-slate-900/80 dark:border-slate-800">
          <div className="relative aspect-[16/10] overflow-hidden rounded-[24px] border border-dashed border-border bg-[linear-gradient(135deg,#e0f4f8,#ffffff)] dark:bg-[linear-gradient(135deg,#1e293b,#0f172a)] flex items-center justify-center">
            {attachment.url ? (
               <img src={attachment.url} alt={attachment.caption} className="w-full h-full object-cover" />
            ) : (
               <div className="flex flex-col items-center justify-center text-slate-400 opacity-60">
                 <ImageIcon className="h-8 w-8 mb-2 opacity-50" />
                 <span className="text-xs uppercase font-medium tracking-widest">No Preview</span>
               </div>
            )}
          </div>
          <div className="mt-4 flex items-center justify-between gap-4">
            <div>
              <div className="font-medium">{attachment.fileName}</div>
              <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{attachment.category}</div>
            </div>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">{attachment.caption}</p>
        </Card>
      ))}
    </div>
  );
}
