import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatDate } from "@/lib/utils";

/** Satu baris hasil uji kuat tekan beton — semua field numerik disimpan sebagai string di DB. */
interface ResultRow {
  id: string;
  rowNumber: number;
  sampleCode: string;
  castingDate: string | Date;
  testingDate: string | Date;
  ageDays: number;
  weight?: string | number | null;
  dimension?: string | null;
  maxLoad?: string | number | null;
  compressiveStrength?: string | number | null;
  failurePattern?: string | null;
  remarks?: string | null;
  analystName?: string | null;
}

function fmtDate(d: string | Date | undefined | null) {
  if (!d) return "—";
  const s = d instanceof Date ? d.toISOString() : d;
  return formatDate(s);
}

function fmtVal(v: string | number | null | undefined, suffix = "") {
  if (v === null || v === undefined || v === "") return "—";
  return `${v}${suffix}`;
}

/** Tabel hasil uji read-only yang ditampilkan di halaman detail dan review. */
export function ResultTable({ rows }: { rows: ResultRow[] }) {
  if (rows.length === 0) {
    return (
      <Card className="p-6 dark:bg-slate-900/80 dark:border-slate-800 text-sm text-muted-foreground italic">
        Belum ada hasil uji yang diinput.
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden p-0 dark:bg-slate-900/80 dark:border-slate-800">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50/80 dark:bg-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800">
              <TableHead>No</TableHead>
              <TableHead>Kode Benda Uji</TableHead>
              <TableHead>Tgl Pembuatan</TableHead>
              <TableHead>Tgl Pengujian</TableHead>
              <TableHead>Umur</TableHead>
              <TableHead>Berat (kg)</TableHead>
              <TableHead>Ukuran</TableHead>
              <TableHead>Beban Maks. (kN)</TableHead>
              <TableHead>Kuat Tekan (MPa)</TableHead>
              <TableHead>Pola Hancur</TableHead>
              <TableHead>Keterangan</TableHead>
              <TableHead>Analis</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row) => (
              <TableRow key={row.id}>
                <TableCell className="font-medium text-muted-foreground">{row.rowNumber}</TableCell>
                <TableCell className="font-semibold">{row.sampleCode}</TableCell>
                <TableCell>{fmtDate(row.castingDate)}</TableCell>
                <TableCell>{fmtDate(row.testingDate)}</TableCell>
                <TableCell>{row.ageDays} hari</TableCell>
                <TableCell>{fmtVal(row.weight)}</TableCell>
                <TableCell>{fmtVal(row.dimension)}</TableCell>
                <TableCell>{fmtVal(row.maxLoad)}</TableCell>
                <TableCell className="font-semibold text-indigo-600 dark:text-indigo-400">
                  {fmtVal(row.compressiveStrength, " MPa")}
                </TableCell>
                <TableCell>{fmtVal(row.failurePattern)}</TableCell>
                <TableCell className="text-muted-foreground">{fmtVal(row.remarks)}</TableCell>
                <TableCell>{fmtVal(row.analystName)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}
