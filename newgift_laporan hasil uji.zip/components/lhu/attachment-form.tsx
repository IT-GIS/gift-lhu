import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { UploadCloud } from "lucide-react";

export function AttachmentForm() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card className="bg-white/85 dark:bg-slate-900/80 p-6 shadow-sm border-slate-200 dark:border-slate-800">
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
          <UploadCloud className="h-5 w-5 text-indigo-500" />
          Lampiran Gambar Produk
        </h3>
        <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer group">
          <div className="h-12 w-12 rounded-full bg-indigo-100 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <UploadCloud className="h-6 w-6 text-indigo-600" />
          </div>
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Klik untuk unggah atau seret gambar ke sini</p>
          <p className="text-xs text-slate-500 mb-4">PNG, JPG, JPEG (Max. 5MB)</p>
          <Input name="attachmentProduk" type="file" accept="image/*" className="max-w-[250px] text-xs file:bg-indigo-50 file:text-indigo-700 file:border-0 file:rounded-md file:px-3 file:py-1 file:mr-3 file:font-medium file:cursor-pointer" />
        </div>
      </Card>

      <Card className="bg-white/85 dark:bg-slate-900/80 p-6 shadow-sm border-slate-200 dark:border-slate-800">
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
          <UploadCloud className="h-5 w-5 text-cyan-500" />
          Lampiran Gambar Pengujian
        </h3>
        <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer group">
          <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <UploadCloud className="h-6 w-6 text-cyan-600" />
          </div>
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Klik untuk unggah atau seret gambar ke sini</p>
          <p className="text-xs text-slate-500 mb-4">PNG, JPG, JPEG (Max. 5MB)</p>
          <Input name="attachmentPengujian" type="file" accept="image/*" className="max-w-[250px] text-xs file:bg-cyan-50 file:text-cyan-700 file:border-0 file:rounded-md file:px-3 file:py-1 file:mr-3 file:font-medium file:cursor-pointer" />
        </div>
      </Card>
    </div>
  );
}
